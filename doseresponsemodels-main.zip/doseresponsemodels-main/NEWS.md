
# doseresponsemodels 0.1.2

- Previous version of the JEMRA dose-response models were wrong
  (inversion susceptible vs healthy population)

# doseresponsemodels 0.1.1

- Includes the marginal (ober sub-populations) dose-response models for
  *Listeria monocytogenes*

# doseresponsemodels 0.1.0

## First release

- Dose response models for *Listeria monocytogenes*
